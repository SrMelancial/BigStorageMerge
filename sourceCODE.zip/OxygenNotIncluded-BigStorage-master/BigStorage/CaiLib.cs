﻿using System;

namespace CaiLib
{
	// Token: 0x02000005 RID: 5
	public interface IModInfo
	{
		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000007 RID: 7
		string Name { get; }
	}
}
