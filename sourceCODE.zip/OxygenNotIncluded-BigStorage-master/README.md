An attempt at larger storage with actual balance. One tier up from regular storage, you'll find larger storage (5x) at a reasonable price.
Includes:
Big Liquid - 5x capacity for twice as much refined metal.
Big Gas - 5x capacity for twice as much refined metal.
Big Solid - 5x capacity for twice as much raw ore.
Big Beautiful Solid - 5x capacity (of the regular storage bin) for twice as much refined metal.

All items are decor-neutral, with the exception of the Big Beautiful Storage Bin, which gives a small bonus. It's as pretty as a sink!

Additionally, all still look like their base item... for now. I will work on at least a color shift next.